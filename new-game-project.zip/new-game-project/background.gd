func _ready():
	background.texture = images[index]
	_fit_to_screen()
	var timer = Timer.new()
	timer.wait_time = 2.0
	timer.timeout.connect(_next_background)
	add_child(timer)
	timer.start()

func _next_background():
	index += 1
	if index >= images.size():
		index = 0
	background.texture = images[index]
	_fit_to_screen()

func _fit_to_screen():
	var viewport_size = get_viewport_rect().size
	var tex_size = background.texture.get_size()
	background.scale = viewport_size / tex_size
	background.position = viewport_size / 2
