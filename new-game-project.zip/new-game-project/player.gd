extends CharacterBody2D

var health = 100
var player_name = "Big D Boss"

func _ready():
	print(player_name, " has arrived to kiss your ass and have a health of ", health, " HP.")
	position.x = 400
	position.y = 400

func take_damage(amount):
	health -= amount
	print("Health: ", health)
